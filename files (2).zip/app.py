"""
Secure Login System
- bcrypt password hashing
- SQL injection protection (parameterized queries)
- Session management with logout
- TOTP-based 2FA (Google Authenticator compatible)
- Input validation
- Brute-force protection (login attempt limiting)
"""

from flask import (
    Flask, render_template, request, redirect,
    url_for, session, flash, jsonify
)
import sqlite3
import bcrypt
import pyotp
import qrcode
import io
import base64
import re
import os
import time
from datetime import datetime, timedelta
from functools import wraps

app = Flask(__name__)
app.secret_key = os.urandom(32)  # Strong random secret key
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=30)

DB_PATH = 'secure_login.db'

# ── Brute-force protection (in-memory) ──
login_attempts = {}  # {ip: [timestamp, ...]}
MAX_ATTEMPTS = 5
LOCKOUT_SECONDS = 300  # 5 minutes


# ─────────────────────────────────────────────
# DATABASE SETUP
# ─────────────────────────────────────────────

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with get_db() as conn:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                totp_secret TEXT,
                two_fa_enabled INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                last_login TEXT
            )
        ''')
        conn.execute('''
            CREATE TABLE IF NOT EXISTS login_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT,
                ip_address TEXT,
                success INTEGER,
                timestamp TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        conn.commit()


# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────

def validate_username(username):
    """Only allow alphanumeric + underscore, 3-20 chars."""
    return bool(re.match(r'^[a-zA-Z0-9_]{3,20}$', username))


def validate_email(email):
    return bool(re.match(r'^[^@\s]+@[^@\s]+\.[^@\s]+$', email))


def validate_password(password):
    """Min 8 chars, at least one uppercase, one digit, one special char."""
    if len(password) < 8:
        return False, "Password must be at least 8 characters."
    if not re.search(r'[A-Z]', password):
        return False, "Password must contain at least one uppercase letter."
    if not re.search(r'\d', password):
        return False, "Password must contain at least one number."
    if not re.search(r'[!@#$%^&*(),.?\":{}|<>]', password):
        return False, "Password must contain at least one special character."
    return True, ""


def is_rate_limited(ip):
    now = time.time()
    attempts = login_attempts.get(ip, [])
    # Remove old attempts
    attempts = [t for t in attempts if now - t < LOCKOUT_SECONDS]
    login_attempts[ip] = attempts
    return len(attempts) >= MAX_ATTEMPTS


def record_attempt(ip):
    login_attempts.setdefault(ip, []).append(time.time())


def log_login(username, ip, success):
    with get_db() as conn:
        conn.execute(
            'INSERT INTO login_log (username, ip_address, success) VALUES (?, ?, ?)',
            (username, ip, 1 if success else 0)
        )
        conn.commit()


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to continue.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated


def generate_qr(totp_uri):
    qr = qrcode.make(totp_uri)
    buf = io.BytesIO()
    qr.save(buf, format='PNG')
    return base64.b64encode(buf.getvalue()).decode()


# ─────────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────────

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        confirm = request.form.get('confirm_password', '')

        # Input validation
        if not validate_username(username):
            flash('Username must be 3–20 characters (letters, numbers, underscore only).', 'error')
            return render_template('register.html')
        if not validate_email(email):
            flash('Please enter a valid email address.', 'error')
            return render_template('register.html')
        valid, msg = validate_password(password)
        if not valid:
            flash(msg, 'error')
            return render_template('register.html')
        if password != confirm:
            flash('Passwords do not match.', 'error')
            return render_template('register.html')

        # Hash password with bcrypt
        password_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt(rounds=12)).decode()

        # Parameterized query — SQL injection safe
        try:
            with get_db() as conn:
                conn.execute(
                    'INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)',
                    (username, email, password_hash)
                )
                conn.commit()
            flash('Account created! Please log in.', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Username or email already exists.', 'error')

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        ip = request.remote_addr
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')

        # Rate limiting
        if is_rate_limited(ip):
            flash('Too many failed attempts. Please wait 5 minutes.', 'error')
            return render_template('login.html')

        # Parameterized query
        with get_db() as conn:
            user = conn.execute(
                'SELECT * FROM users WHERE username = ?', (username,)
            ).fetchone()

        if user and bcrypt.checkpw(password.encode(), user['password_hash'].encode()):
            # Password correct
            if user['two_fa_enabled']:
                # Store pending state for 2FA step
                session['pending_2fa_user_id'] = user['id']
                session['pending_2fa_username'] = user['username']
                return redirect(url_for('verify_2fa'))
            else:
                # Full login
                session.permanent = True
                session['user_id'] = user['id']
                session['username'] = user['username']
                with get_db() as conn:
                    conn.execute('UPDATE users SET last_login=? WHERE id=?',
                                 (datetime.now().isoformat(), user['id']))
                    conn.commit()
                log_login(username, ip, True)
                flash(f'Welcome back, {username}!', 'success')
                return redirect(url_for('dashboard'))
        else:
            record_attempt(ip)
            log_login(username, ip, False)
            flash('Invalid username or password.', 'error')

    return render_template('login.html')


@app.route('/verify-2fa', methods=['GET', 'POST'])
def verify_2fa():
    if 'pending_2fa_user_id' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        code = request.form.get('code', '').strip()
        user_id = session['pending_2fa_user_id']

        with get_db() as conn:
            user = conn.execute('SELECT * FROM users WHERE id=?', (user_id,)).fetchone()

        totp = pyotp.TOTP(user['totp_secret'])
        if totp.verify(code, valid_window=1):
            session.pop('pending_2fa_user_id', None)
            session.pop('pending_2fa_username', None)
            session.permanent = True
            session['user_id'] = user['id']
            session['username'] = user['username']
            with get_db() as conn:
                conn.execute('UPDATE users SET last_login=? WHERE id=?',
                             (datetime.now().isoformat(), user['id']))
                conn.commit()
            flash(f'Welcome back, {user["username"]}!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid 2FA code. Please try again.', 'error')

    return render_template('verify_2fa.html', username=session.get('pending_2fa_username'))


@app.route('/dashboard')
@login_required
def dashboard():
    with get_db() as conn:
        user = conn.execute('SELECT * FROM users WHERE id=?', (session['user_id'],)).fetchone()
        logs = conn.execute(
            'SELECT * FROM login_log WHERE username=? ORDER BY timestamp DESC LIMIT 5',
            (user['username'],)
        ).fetchall()
    return render_template('dashboard.html', user=user, logs=logs)


@app.route('/setup-2fa', methods=['GET', 'POST'])
@login_required
def setup_2fa():
    with get_db() as conn:
        user = conn.execute('SELECT * FROM users WHERE id=?', (session['user_id'],)).fetchone()

    if request.method == 'POST':
        code = request.form.get('code', '').strip()
        secret = session.get('totp_secret_temp')
        if not secret:
            return redirect(url_for('setup_2fa'))
        totp = pyotp.TOTP(secret)
        if totp.verify(code, valid_window=1):
            with get_db() as conn:
                conn.execute(
                    'UPDATE users SET totp_secret=?, two_fa_enabled=1 WHERE id=?',
                    (secret, session['user_id'])
                )
                conn.commit()
            session.pop('totp_secret_temp', None)
            flash('Two-Factor Authentication enabled!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid code. Please scan QR again and retry.', 'error')

    # Generate new TOTP secret
    secret = pyotp.random_base32()
    session['totp_secret_temp'] = secret
    totp_uri = pyotp.totp.TOTP(secret).provisioning_uri(
        name=user['email'], issuer_name='SecureLoginApp'
    )
    qr_image = generate_qr(totp_uri)
    return render_template('setup_2fa.html', qr_image=qr_image, secret=secret)


@app.route('/disable-2fa', methods=['POST'])
@login_required
def disable_2fa():
    with get_db() as conn:
        conn.execute(
            'UPDATE users SET totp_secret=NULL, two_fa_enabled=0 WHERE id=?',
            (session['user_id'],)
        )
        conn.commit()
    flash('Two-Factor Authentication disabled.', 'success')
    return redirect(url_for('dashboard'))


@app.route('/logout')
@login_required
def logout():
    session.clear()
    flash('You have been logged out.', 'success')
    return redirect(url_for('login'))


if __name__ == '__main__':
    init_db()
    app.run(debug=True, port=5000)

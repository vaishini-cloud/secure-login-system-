# 🔐 Secure Login System

A full-stack secure web login system built with **Flask** featuring bcrypt password hashing, SQL injection protection, session management, and optional TOTP-based Two-Factor Authentication.

---

## 🛡️ Security Features

| Feature | Implementation |
|---|---|
| Password Hashing | bcrypt with cost factor 12 |
| SQL Injection Protection | Parameterized queries (SQLite) |
| Session Management | Flask sessions with 30-min timeout, HttpOnly cookies |
| Brute-force Protection | 5 attempts → 5-minute IP lockout |
| Input Validation | Regex: username, email, password strength |
| 2FA (Optional) | TOTP via pyotp — Google Authenticator / Authy compatible |
| Login Audit Log | Every login attempt logged with IP and timestamp |

---

## 📁 Project Structure

```
secure_login/
│
├── app.py                    # Main Flask application
├── requirements.txt          # Python dependencies
├── secure_login.db           # SQLite database (auto-created)
│
└── templates/
    ├── base.html             # Base layout with nav & styles
    ├── register.html         # Registration form + password strength
    ├── login.html            # Login form
    ├── dashboard.html        # User dashboard + login history
    ├── setup_2fa.html        # QR code 2FA setup
    └── verify_2fa.html       # 2FA code entry
```

---

## ▶️ How to Run

**1. Install dependencies**
```bash
pip install -r requirements.txt
```

**2. Start the server**
```bash
python app.py
```

**3. Open in browser**
```
http://localhost:5000
```

---

## 🔑 Password Requirements

- Minimum 8 characters
- At least one uppercase letter
- At least one number
- At least one special character (`!@#$%^&*` etc.)

---

## 📱 2FA Setup (Optional)

1. Register and log in
2. Go to Dashboard → **Enable 2FA**
3. Scan the QR code with **Google Authenticator** or **Authy**
4. Enter the 6-digit code to activate
5. Future logins will require the code after password verification

---

## 🔒 Security Implementation Details

**bcrypt hashing:**
```python
password_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt(rounds=12)).decode()
```

**Parameterized queries (SQL injection safe):**
```python
user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
```

**Brute-force protection:**
```python
MAX_ATTEMPTS = 5
LOCKOUT_SECONDS = 300  # 5 minutes per IP
```

**Session security:**
```python
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=30)
```

---

## 📦 Dependencies

- Python 3.8+
- Flask
- bcrypt
- pyotp
- qrcode
- Pillow

---

## 👤 Author

Built as part of a Web Security / Machine Learning project submission.
